In acest director se vor stoca:

1) articolul in format DOC (WORD), conform template. 
Minim 6 pagini, maxim 10 pagini.

2) prezentarea PPT (format liber). Prezentarea va contine
minim 6 slide-uri corespunzatoare progresului proiectului la fiecare 2 saptamani
+ un numar de slideuri aferent prezentarii rezultatelor experimentale.

