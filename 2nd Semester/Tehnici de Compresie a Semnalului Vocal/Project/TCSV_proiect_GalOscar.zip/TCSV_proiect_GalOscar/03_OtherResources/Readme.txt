In acest director se vor stoca:
- resurse de documentare folosite si strict importante (articole, prezentari PPT, etc)


