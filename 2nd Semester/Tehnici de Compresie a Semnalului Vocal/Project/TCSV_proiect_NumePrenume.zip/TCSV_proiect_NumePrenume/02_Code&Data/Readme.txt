In acest director se va stoca:

1) partea de dezvoltare software (codul) si datele, in structura arborescenta aferenta;

2) un fisier text cu instuctiuni de utilizare a codului 
(resurse necesare pentru instalare, etape de lucru, etc)


